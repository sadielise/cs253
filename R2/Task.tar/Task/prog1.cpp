#include <iostream>

using namespace std;

void speak() {
	cout << "I'm speaking from prog1\n";
}
