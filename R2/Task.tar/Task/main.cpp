#include <iostream>
using namespace std;

#include "prog1.h"

int main() {
	cout << "Hello from main()\n";
	cout << "Calling speak() from main()\n";
	speak();	
	return 0;
}
