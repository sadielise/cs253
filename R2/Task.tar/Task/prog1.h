void speak();
