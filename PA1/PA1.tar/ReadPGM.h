// including
#include <fstream>
#include <istream>
#include <iostream>
#include <string>

// using
using std::ifstream;
using std::string;

class ReadPGM
{

	public:
		int readFile(string filename);

	private:
		string file;

};



