
int fib(int);
